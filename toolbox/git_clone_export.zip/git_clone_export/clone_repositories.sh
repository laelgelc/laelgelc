#!/usr/bin/env bash
set -u

FAILED=0

clone_repo() {
    local url="$1"
    local target="$2"
    local branch="$3"

    echo "Cloning ${url} into ${target}"

    if [ -d "${target}/.git" ] || [ -f "${target}/.git" ]; then
        echo "Repository already exists, skipping: ${target}"
        return 0
    fi

    mkdir -p "$(dirname "${target}")"

    if [ -n "${branch}" ]; then
        git clone --branch "${branch}" "${url}" "${target}" || {
            echo "Failed to clone ${url}" >&2
            FAILED=1
            return 1
        }
    else
        git clone "${url}" "${target}" || {
            echo "Failed to clone ${url}" >&2
            FAILED=1
            return 1
        }
    fi
}

echo "Starting repository clone operation"
echo "Repositories will be cloned relative to: $(pwd)"

clone_repo 'git@github.com:eyamrog/aacl_2026_workshop.git' 'aacl_2026_workshop' 'main'

clone_repo 'git@github.com:laelgelc/cl_latex_ws.git' 'cl_latex_ws' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_andrea.git' 'cl_st1_andrea' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_andressa.git' 'cl_st1_andressa' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_anna.git' 'cl_st1_anna' 'main'

clone_repo 'git@github.com:/laelgelc/cl_st1_claudia.git' 'cl_st1_claudia' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_ednalvo.git' 'cl_st1_ednalvo' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_julio.git' 'cl_st1_julio' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_leticia.git' 'cl_st1_leticia' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_marcia.git' 'cl_st1_marcia' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_melina.git' 'cl_st1_melina' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_milena.git' 'cl_st1_milena' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_sara.git' 'cl_st1_sara' 'main'

clone_repo 'git@github.com:laelgelc/cl_st1_tatiana.git' 'cl_st1_tatiana' 'main'

clone_repo 'git@github.com:laelgelc/cl_st2_arianne.git' 'cl_st2_arianne' 'main'

clone_repo 'git@github.com:eyamrog/delta.git' 'delta' 'main'

clone_repo 'git@github.com:eyamrog/eyamrog_latex.git' 'eyamrog_latex' 'main'

clone_repo 'git@github.com:laelgelc/gelc_lmda.git' 'gelc_lmda' 'main'

clone_repo 'git@github.com:laelgelc/laelgelc.git' 'laelgelc' 'main'

clone_repo 'git@github.com:laelgelc/laelgelc_toolbox.git' 'laelgelc_toolbox' 'main'

clone_repo 'git@github.com:eyamrog/ry_folder.git' 'ry_folder' 'main'

clone_repo 'git@github.com:jcollentine/vem-corpus.git' 'vem-corpus' 'main'

if [ "${FAILED}" -ne 0 ]; then
    echo "One or more repositories failed to clone." >&2
else
    echo "All clone operations completed successfully."
fi

exit "${FAILED}"
